import torch
from torch.distributions import Categorical
import numpy as np

def select_action(policy, obs):
    dist = Categorical(policy(obs))
    action = dist.sample()
    log_prob = dist.log_prob(action)
    return action.item(), log_prob.reshape(1)

def compute_returns(rewards, gamma):
    returns = np.flip(np.cumsum([gamma**(i+1) * r for i, r in enumerate(rewards)][::-1]), 0).copy()
    return returns