import torch
from .utils import select_action, compute_returns

def run_episode(env, policy, maxlen=500):
    obs, _ = env.reset()
    observations, actions, log_probs, rewards = [], [], [], []

    for _ in range(maxlen):
        obs_tensor = torch.tensor(obs, dtype=torch.float32)
        action, log_prob = select_action(policy, obs_tensor)
        observations.append(obs_tensor)
        actions.append(action)
        log_probs.append(log_prob)

        obs, reward, terminated, truncated, _ = env.step(action)
        rewards.append(reward)
        if terminated or truncated:
            break

    return observations, actions, torch.cat(log_probs), rewards

def reinforce(policy, env, env_render=None, gamma=0.99, num_episodes=1000, lr=1e-2):
    optimizer = torch.optim.Adam(policy.parameters(), lr=lr)
    running_rewards = [0.0]

    for episode in range(num_episodes):
        _, _, log_probs, rewards = run_episode(env, policy)
        returns = torch.tensor(compute_returns(rewards, gamma), dtype=torch.float32)
        running_rewards.append(0.05 * returns[0].item() + 0.95 * running_rewards[-1])

        returns = (returns - returns.mean()) / (returns.std() + 1e-9)
        loss = (-log_probs * returns).mean()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if episode % 100 == 0:
            if env_render:
                policy.eval()
                run_episode(env_render, policy)
                policy.train()
            print(f"Episode {episode}, Running Reward: {running_rewards[-1]:.2f}")

    return running_rewards