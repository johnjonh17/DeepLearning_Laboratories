import gymnasium as gym
import numpy as np
import torch
import matplotlib.pyplot as plt
from cartpole_rl.policy import PolicyNet
from cartpole_rl.agent import reinforce

# Seed for reproducibility
seed = 2112
torch.manual_seed(seed)
np.random.seed(seed)

# Instantiate both environments: one for training, one for rendering
env = gym.make("CartPole-v1")
env.reset(seed=seed)
env_render = gym.make("CartPole-v1", render_mode="human")

# Initialize policy
policy = PolicyNet(env.observation_space.shape[0], env.action_space.n)

# Train the agent with optional rendering
rewards = reinforce(policy, env, env_render=env_render, num_episodes=500)

# Plot the learning curve
plt.plot(rewards)
plt.xlabel("Episode")
plt.ylabel("Running Reward")
plt.title("REINFORCE on CartPole")
plt.grid()
plt.show()